const fs = require('fs');
const path = require('path');
const sharp = require('sharp');
const { v4: uuidv4 } = require('uuid');

async function renderCertificatePNG({ name, score, total, certId }) {
  // Load SVG template
  const svgPath = path.join(__dirname, '..', 'assets', 'certificate-template.svg');
  let svg = fs.readFileSync(svgPath, 'utf8');
  // Replace placeholders
  svg = svg.replace('[Participant Name]', name || 'Participant')
           .replace('[SCORE]', String(score || '0'))
           .replace('[TOTAL]', String(total || '0'))
           .replace('[CERTID]', certId || uuidv4().slice(0,8));
  // Use sharp to convert SVG string to PNG buffer
  const pngBuffer = await sharp(Buffer.from(svg)).png({ quality: 90 }).toBuffer();
  return pngBuffer;
}

module.exports = { renderCertificatePNG };