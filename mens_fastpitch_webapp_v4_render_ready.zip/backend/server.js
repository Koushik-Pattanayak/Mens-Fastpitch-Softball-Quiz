const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const PDFDocument = require('pdfkit');
const bcrypt = require('bcrypt');
const nodemailer = require('nodemailer');
const app = express();
app.use(cors());
app.use(express.json());

const SECRET = process.env.JWT_SECRET || 'replace_with_secure_secret';
const DATA_DIR = path.join(__dirname, 'data');
const QUESTIONS_FILE = path.join(DATA_DIR, 'questions.json');
const RESULTS_FILE = path.join(DATA_DIR, 'results.json');

// Postgres pool if DATABASE_URL is set
let pool = null;
if(process.env.DATABASE_URL) {
  pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSLMODE ? { rejectUnauthorized: false } : false });
  console.log('Postgres pool created');
}

// Simple user store (for demo). In production, use DB.
const usersFile = path.join(DATA_DIR, 'users.json');
let users = [];
if(fs.existsSync(usersFile)) {
  users = JSON.parse(fs.readFileSync(usersFile));
} else {
  // create default admin user (password: adminpass)
  const defaultAdmin = { id: 1, username: 'admin', passwordHash: '' };
  const salt = bcrypt.genSaltSync(10);
  defaultAdmin.passwordHash = bcrypt.hashSync('adminpass', salt);
  users = [defaultAdmin];
  fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
}

// Nodemailer transporter configuration - expects SMTP env vars for production
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.example.com',
  port: process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT) : 587,
  secure: false,
  auth: {
    user: process.env.SMTP_USER || 'user@example.com',
    pass: process.env.SMTP_PASS || 'password'
  }
});

async function sendEmail(to, subject, text, html) {
  try {
    const info = await transporter.sendMail({ from: process.env.SMTP_FROM || 'no-reply@fastpitchquiz.com', to, subject, text, html });
    console.log('Email sent', info.messageId);
  } catch (err) {
    console.error('Error sending email', err.message || err);
  }
}

app.post('/api/auth/register', async (req, res) => {
  const { username, password, email } = req.body;
  if(!username || !password || !email) return res.status(400).json({ error: 'Missing fields' });
  if(users.find(u=>u.username===username)) return res.status(400).json({ error: 'User exists' });
  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash(password, salt);
  const newUser = { id: users.length + 1, username, email, passwordHash: hash, role: 'user' };
  users.push(newUser);
  fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
  // send welcome email
  sendEmail(email, 'Welcome to Men\'s Fastpitch Quiz', `Hi ${username},\n\nThanks for registering.`, `<p>Hi ${username},</p><p>Thanks for registering for the Men's Fastpitch Quiz.</p>`);
  res.json({ status: 'ok' });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u=>u.username===username);
  if(!user) return res.status(401).json({ error: 'Invalid credentials' });
  const valid = bcrypt.compareSync(password, user.passwordHash);
  if(!valid) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: user.id, username: user.username, role: user.role || 'user' }, SECRET, { expiresIn: '8h' });
  res.json({ token });
});

function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if(!auth) return res.status(401).json({ error: 'Missing token' });
  const token = auth.split(' ')[1];
  try {
    const data = jwt.verify(token, SECRET);
    req.user = data;
    next();
  } catch(e) { return res.status(401).json({ error: 'Invalid token' }); }
}

app.get('/api/questions', async (req, res) => {
  const category = req.query.category;
  if(pool) {
    try {
      const q = category ? await pool.query('SELECT * FROM questions WHERE category=$1 ORDER BY id', [category]) : await pool.query('SELECT * FROM questions ORDER BY id');
      return res.json(q.rows);
    } catch(err){ console.error(err); return res.status(500).json({error:'db error'}); }
  } else {
    const raw = fs.readFileSync(QUESTIONS_FILE);
    const all = JSON.parse(raw);
    if (category) return res.json(all.filter(q=>q.category===category));
    res.json(all);
  }
});

app.post('/api/results', async (req, res) => {
  const result = req.body;
  // send email to user if email provided
  if(result.email) {
    sendEmail(result.email, 'Your Quiz Results', `You scored ${result.score}/${result.total}`, `<p>You scored <strong>${result.score}/${result.total}</strong>.</p>`);
  }
  if(pool) {
    try {
      const insert = await pool.query('INSERT INTO results(user_name,score,total,submitted_at) VALUES($1,$2,$3, NOW()) RETURNING id', [result.name || null, result.score, result.total]);
      return res.json({ status: 'ok', id: insert.rows[0].id });
    } catch(err){ console.error(err); return res.status(500).json({error:'db error'}); }
  } else {
    const results = fs.existsSync(RESULTS_FILE) ? JSON.parse(fs.readFileSync(RESULTS_FILE)) : [];
    results.push(result);
    fs.writeFileSync(RESULTS_FILE, JSON.stringify(results, null, 2));
    res.json({ status: 'ok' });
  }
});

app.post('/api/generate-certificate', (req, res) => {
  const { name, score, total, signed } = req.body;
  const doc = new PDFDocument({ size: 'A4', margin: 50 });
  const buffers = [];
  doc.on('data', buffers.push.bind(buffers));
  doc.on('end', () => {
    const pdfData = Buffer.concat(buffers);
    // send email with certificate as attachment if email provided? client can request both
    res.json({ filename: `certificate-${Date.now()}.pdf`, data: pdfData.toString('base64') });
  });

  // Use enhanced certificate design: draw background rectangle, title, name, score, date, signature line
  doc.rect(0, 0, doc.page.width, doc.page.height).fill('#ffffff');
  doc.fillColor('#2c3e50');
  doc.fontSize(28).text('Certificate of Completion', { align: 'center' });
  doc.moveDown(2);
  doc.fontSize(16).text('This certifies that', { align: 'center' });
  doc.moveDown(1);
  doc.font('Helvetica-Bold').fontSize(26).text(name || 'Participant', { align: 'center' });
  doc.moveDown(1);
  doc.font('Helvetica').fontSize(14).text(`Has completed the Men's Fastpitch Quiz with a score of ${score}/${total}`, { align: 'center' });
  doc.moveDown(2);
  doc.fontSize(12).text(`Date: ${new Date().toLocaleDateString()}`, { align: 'center' });
  if(signed) {
    doc.moveDown(3);
    doc.fontSize(12).text('__________________________', { align: 'center' });
    doc.fontSize(10).text('Official Signature', { align: 'center' });
  }
  doc.end();
});

app.get('/', (req, res) => res.send("Men's Fastpitch Quiz Backend (v3) with email and registration running"));
const port = process.env.PORT || 5000;
app.listen(port, () => console.log('Server running on port', port));
