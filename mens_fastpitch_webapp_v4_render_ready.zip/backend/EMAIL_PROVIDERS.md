# Email provider sample configurations

## SendGrid (recommended)
Nodemailer transport example using SendGrid SMTP:
```
host: 'smtp.sendgrid.net',
port: 587,
auth: { user: 'apikey', pass: process.env.SENDGRID_API_KEY }
```
Environment variables to set: `SENDGRID_API_KEY` (and set SMTP_USER to 'apikey' if using nodemailer SMTP)

## Mailgun
Nodemailer SMTP example for Mailgun:
```
host: 'smtp.mailgun.org',
port: 587,
auth: { user: process.env.MAILGUN_SMTP_LOGIN, pass: process.env.MAILGUN_SMTP_PASSWORD }
```
Set `MAILGUN_SMTP_LOGIN` and `MAILGUN_SMTP_PASSWORD` in environment.

## Using Nodemailer with API (SendGrid)
You can also use SendGrid's API client rather than SMTP for higher throughput and deliverability.
