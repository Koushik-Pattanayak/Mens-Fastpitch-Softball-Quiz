-- Create questions and results tables
CREATE TABLE IF NOT EXISTS questions (
  id SERIAL PRIMARY KEY,
  category TEXT NOT NULL,
  en TEXT NOT NULL,
  hi TEXT,
  options JSONB NOT NULL,
  answer TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS results (
  id SERIAL PRIMARY KEY,
  user_name TEXT,
  score INT,
  total INT,
  submitted_at TIMESTAMP DEFAULT NOW()
);
