Men's Fastpitch Quiz - Full Web App (v3)

What's included:
- Frontend: React (Vite) app in frontend/
- Backend: Express API in backend/ with Postgres support
- Docker + docker-compose for local deployment (frontend, backend, Postgres)
- migrations.sql and seed_questions.sql to set up DB
- Certificate generation endpoint (/api/generate-certificate)
- JWT admin login (demo creds: admin / adminpass) — change in production
- 500 questions with English and Hindi fields (machine-assisted translations; review recommended)

Quick local with Docker (recommended):
1. Install Docker & docker-compose
2. From project root run: docker-compose up --build
3. After Postgres initializes, run migrations & seed (psql or use admin tool):
   - psql -h localhost -U fpuser -d fastpitchdb -f backend/migrations.sql
   - psql -h localhost -U fpuser -d fastpitchdb -f backend/seed_questions.sql
4. Frontend will be at http://localhost:3000, backend at http://localhost:5000

Heroku / Cloud deploy notes:
- Backend: set DATABASE_URL env var, set JWT_SECRET; ensure pg buildpack.
- Frontend: can be deployed to Vercel/Netlify; point API base to backend URL.
- For PDF signing, integrate secure key management and certificate signing in production.

Translations:
- Hindi translations were generated automatically and saved in backend/data/questions.json. Please have a native speaker review them before production use.

Security:
- Replace demo admin credentials and set secure JWT_SECRET via env vars.
- Use HTTPS in production and secure database credentials.



## Registration & Email

The backend supports user registration (`/api/auth/register`) and sends a welcome email. Configure SMTP via environment variables:

- `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM`

When results are submitted with an `email` field, the server will email the score to that address. Secure SMTP credentials in production.


## CI/CD & Deployment

- GitHub Actions workflows are included (.github/workflows) to build/push Docker images and trigger deploys on Render or Heroku. Configure secrets in your repo settings.
- Terraform for AWS ECS (basic ECR & IAM resources) provided in infra/aws-ecs; customize for full ECS/Fargate stack.

## Email Providers
- See backend/EMAIL_PROVIDERS.md for SendGrid/Mailgun examples.


## Server-side SVG rendering and PNG export

The backend now includes `render_certificate.js` which uses `sharp` to convert the SVG certificate template into a PNG. `server_v4.js` demonstrates how to generate a PNG, embed it into a PDF, and email both PNG and PDF as attachments.

## Terraform GitHub Action

A workflow `terraform_apply.yml` is included to run Terraform `init/plan/apply` on push or manual dispatch. Configure `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` in GitHub Secrets.

## Render one-click deploy

A `render.yaml` file is included to enable deploying backend and frontend services to Render via their GitHub integration.

