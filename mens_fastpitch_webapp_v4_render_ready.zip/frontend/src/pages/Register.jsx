import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Register() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const submit = async () => {
    try {
      const res = await axios.post('/api/auth/register', { username, email, password });
      setMessage('Registration successful! Check your email.');
      setTimeout(()=>navigate('/login'), 1500);
    } catch (e) {
      setMessage(e.response?.data?.error || 'Registration failed');
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded shadow">
      <h2 className="text-xl font-bold mb-4">Register</h2>
      {message && <div className="mb-2">{message}</div>}
      <input value={username} onChange={e=>setUsername(e.target.value)} placeholder="Username" className="w-full mb-2 p-2 border rounded" />
      <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" className="w-full mb-2 p-2 border rounded" />
      <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" className="w-full mb-2 p-2 border rounded" />
      <button onClick={submit} className="bg-blue-600 text-white px-4 py-2 rounded">Register</button>
    </div>
  );
}
